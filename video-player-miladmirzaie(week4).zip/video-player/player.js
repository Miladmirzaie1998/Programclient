var tst=document.getElementById("play-pause");
var video11=document.getElementById("volume1");
var volom=document.getElementById("volum");
    function play2(){
    if(video11.paused || video11.ended)
    {
        video11.play();
        tst.className="actionbig2";

}       
    
    else{
    
        video11.pause();
        tst.className="actionbig";       
        
    }
 
}

    
    function next3(){
       video11.currentTime+=15;
       
    }
    
    function perv1(){
       video11.currentTime-=15; 
    }
function volume33(){
    if(video11.muted==false){
video11.muted=true;
volom.className="vl";
}
else{
    volom.className="volum";
    video11.muted=false;
}
}

var volume1=document.getElementById("plus");
volume1.addEventListener("change", function(){
    video11.volume=volume1.value;
});

var seekbar=document.getElementById("progg");
seekbar.addEventListener("timeupdate",function(){
    var value1=(100/video11.duration)*video11.currentTime;
    seekbar.value=value1;
});
seekbar.addEventListener("change",function(){
    var newtime=video11.duration*(seekbar.value/100);
    video11.currentTime=newtime;
});
function down(){
    
    alert("demo download mp4");
}

const media=window.matchMedia("(max-width:768px)");
var vid=document.querySelector(".video1");
var cc=document.querySelector(".conteiner");
var niv=document.querySelector(".navigation");
var pr=document.querySelector(".pro");
if(media.matches){
    vid.className="film";  
    cc.className="conti";
    niv.className="navi";
    pr.className="prro";
}